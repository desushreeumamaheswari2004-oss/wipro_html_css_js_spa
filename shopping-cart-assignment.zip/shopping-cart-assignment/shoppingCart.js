let cart = [];

function addItemToCart(name, price, quantity) {
    const item = {name, price, quantity };
    cart.push(item);
    return cart;
}

function removeItemFromCart(ItemName) {
    cart = cart.filter(item => item.name !== ItemName);
    return cart;
}

function calculateTotalPrice() {
    let total = 0;
    for (let item of cart) {
        total += item.price * item.quantity;
    }
    return total;
}

function applyDiscountCode(code) {
    const subtotal = calculateTotalPrice();
    let discount = 0;
    if (code == "SAVE10") discount = 0.10;
    else if (code == "SAVE20") discount = 0.20;
    else if (code == "SAVE30") discount = 0.30;
    return subtotal - subtotal * discount;
}

function calculateTax(taxRate) {
    const subtotal = calculateTotalPrice();
    return  subtotal * taxRate;
}

function checkout(taxRate, discountCode) {
    const subtotal = calculateTotalPrice();
    const tax = calculateTax(taxRate);
    let total = subtotal + tax;
    if (discountCode) {
        let discount = 0;
        if (discountCode === "SAVE10") discount = 0.10;
        else if (discountCode === "SAVE20") discount = 0.20;
        else if (discountCode === "SAVE30") discount = 0.30;
        total = total - total * discount;
    }
    
    cart.length = 0;
    return total;
}

module.exports = {
    addItemToCart,
    removeItemFromCart,
    calculateTotalPrice,
    applyDiscountCode,
    calculateTax,
    checkout
};