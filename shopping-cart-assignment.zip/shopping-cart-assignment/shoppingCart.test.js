const cart = require('shoppingCart');
describe('Shopping Cart Service', () => {
    beforeEach(() => {
        cart.checkout(0, null);
    });
    test('should add item to cart', () => {
        cart.addItemToCart('Book', 100, 2);
expect(cart.calculateTotalPrice()).toBe(200);
    });
    test('should remove item from cart', () => { cart.addItemToCart('Pen', 50, 1);
        cart.removeItemFromCart('Pen', 50, 1);
        expect(cart.calculateTotalPrice()).toBe(0);
    });
    test('should calculate total price correctly', () => { cart.addItemToCart('Book', 100, 2);
        cart.addItemToCart('Pen', 50, 1); 
        expect(cart.calculateTotalPrice()).toBe(250);
    });
    test('should apply discount code correctly', () => {
        cart.addItemToCart('Bag', 1000, 1);
        const discounted = cart.applyDiscountCode('SAVE10');
        expect(discounted).toBe(900);
    });
    test('should calculate tax before discount', () => {
        cart.addItemToCart('Shoes', 1000, 1);
        expect(cart.calculateTax(0, 1)).toBe(100);
    });
    test('should checkout and clear cart', () => {
        cart.addItemToCart('Laptop', 1000, 1);
        const total = cart.checkout(0.1, 'SAVE10');
        expect(total).toBe(990);
        expect(cart.calculateTotalPrice()).toBe(0);
    });
});