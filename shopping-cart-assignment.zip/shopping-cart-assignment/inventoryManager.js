let inventory = [];

function addProduct(product) {
    const exists = inventory.find(p => p.productID === product.productID);
    if (exists) {
        throw new Error("Product already exists");
    }
    inventory.push(product);
    return product;
}

function getProductById(productID) {
    const product = inventory.find(p => p.productID === productID);
    return product || null;
}

function updateProduct(productID, updates) {
    const product = inventory.find(p => p.productID === productID);
    if(!product) {
        throw new Error("Product not found");
    }
    Object.keys(updates).forEach(key => {
        if (key !== "productID") {
            product[key] = update[key];
        }
    });
    return product;
}

function deleteProduct(productID) {
    const index = inventory.findIndex(p => p.productID === productID);
    if (index === -1) {
        throw new Error("Product not found");
    }
    inventory.splice(index, 1);
}

function listAllProducts() {
    return inventory;
}

module.exports = {
    addProduct,
    getProductById,
    updateProduct,
    deleteProduct,
    listAllProducts
}