const inventory = require('inventory');

describe('Inventory Management Service', () => {

  beforeEach(() => {
    // reset inventory before each test
    inventory.listAllProducts().length = 0;
  });

  test('should add a new product', () => {
    const product = { productID: 1, name: 'Laptop', price: 50000 };
    inventory.addProduct(product);
    expect(inventory.getProductById(1)).toEqual(product);
  });

  test('should not allow duplicate product ID', () => {
    const product = { productID: 1, name: 'Laptop', price: 50000 };
    inventory.addProduct(product);
    expect(() => inventory.addProduct(product)).toThrow();
  });

  test('should retrieve product by ID', () => {
    const product = { productID: 2, name: 'Phone', price: 20000 };
    inventory.addProduct(product);
    expect(inventory.getProductById(2).name).toBe('Phone');
  });

  test('should return null if product not found', () => {
    expect(inventory.getProductById(99)).toBeNull();
  });

  test('should update product details', () => {
    const product = { productID: 3, name: 'Tablet', price: 15000 };
    inventory.addProduct(product);
    inventory.updateProduct(3, { price: 14000 });
    expect(inventory.getProductById(3).price).toBe(14000);
  });

  test('should delete product by ID', () => {
    const product = { productID: 4, name: 'Mouse', price: 500 };
    inventory.addProduct(product);
    inventory.deleteProduct(4);
    expect(inventory.getProductById(4)).toBeNull();
  });

  test('should list all products', () => {
    inventory.addProduct({ productID: 5, name: 'Keyboard', price: 1000 });
    inventory.addProduct({ productID: 6, name: 'Monitor', price: 8000 });
    expect(inventory.listAllProducts().length).toBe(2);
  });

});
