// Step 1: Import Express
const express = require("express");

// Step 2: Create Express app
const app = express();

// Step 3: Define PORT
const PORT = process.env.PORT || 3000;

// Health API
app.get("/api/health", (req, res) => {
  res.json({ status: "OK" });
});

// Root route
app.get("/", (req, res) => {
  res.send("Hello, World!");
});

// About route
app.get("/about", (req, res) => {
  res.send("This is the about page.");
});

// Route with parameter
app.get("/user/:name", (req, res) => {
  const userName = req.params.name;
  res.send(`Hello, ${userName}!`);
});

// API returning JSON user data
app.get("/api/user", (req, res) => {
  const userData = {
    id: 1,
    name: "John Doe",
    email: "john.doe@example.com",
  };
  res.json(userData);
});

// Start server
app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});

// Export app
module.exports = app;